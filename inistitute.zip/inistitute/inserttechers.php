<?php require_once('Connections/cndata.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE teachers SET tech_name=%s, major=%s, address=%s, Phone=%s, cources=%s WHERE id=%s",
                       GetSQLValueString($_POST['tech_name'], "text"),
                       GetSQLValueString($_POST['major'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['Phone'], "int"),
                       GetSQLValueString($_POST['cources'], "text"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_cndata, $cndata);
  $Result1 = mysql_query($updateSQL, $cndata) or die(mysql_error());

  $updateGoTo = "techers.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form2")) {
  $insertSQL = sprintf("INSERT INTO teachers (tech_name, major, address, Phone, cources) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['tech_name'], "text"),
                       GetSQLValueString($_POST['major'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['Phone'], "int"),
                       GetSQLValueString($_POST['cources'], "text"));

  mysql_select_db($database_cndata, $cndata);
  $Result1 = mysql_query($insertSQL, $cndata) or die(mysql_error());

  $insertGoTo = "techers.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_cndata, $cndata);
$query_Recordset1 = "SELECT * FROM teachers";
$Recordset1 = mysql_query($query_Recordset1, $cndata) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>الدورات</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--
Template 2042 The Block
http://www.tooplate.com/view/2042-the-block
-->
<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />
  
<!-- Arquivos utilizados pelo jQuery lightBox plugin -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
<!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->

<!-- Ativando o jQuery lightBox plugin -->
<script type="text/javascript">
$(function() {
    $('#map a').lightBox();
});
</script>

</head>
<body>

<div id="tooplate_wrapper">

	<div id="tooplate_header">
	  <div id="tooplate_menu">
          <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li>
                  <div align="right"><a href="techers.php" class="current">رجوع</a></div>
              </li>
            </ul>    	
        </div> <!-- end of tooplate_menu -->
    </div> 
	<div align="center"><!-- end of forever header -->
	  
  </div>
	<div align="center"><!-- end of middle -->
	  
  </div>
	<div id="tooplate_content">
      <form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
        <div align="center">
          <table align="center" dir="rtl">
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">اسم المدرب</td>
              <td><input type="text" name="tech_name" value="" size="32" /></td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">التخصص</td>
              <td><input type="text" name="major" value="" size="32" /></td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right" valign="top">العنوان</td>
              <td><textarea name="address" cols="50" rows="5"></textarea></td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">الهاتف</td>
              <td><input type="text" name="Phone" value="" size="32" /></td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right" valign="top">الكورسات</td>
              <td><textarea name="cources" cols="50" rows="5"></textarea></td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">&nbsp;</td>
              <td><div align="justify">
                <input type="submit" value="اضافة" />
              </div></td>
            </tr>
          </table>
          <input type="hidden" name="MM_insert" value="form2" />
        </div>
      </form>
      <p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
	  <h3>&nbsp;</h3>
	  <form id="form1" name="form1" method="post" action="">
	    <div align="center"></div>
	  </form>
	  <p>&nbsp;</p>
	</div> <!-- end of content -->
    
    <div id="tooplate_footer">2018
      <div class="cleaner"></div>
	</div>

</div> <!-- end of wrapper -->

</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
