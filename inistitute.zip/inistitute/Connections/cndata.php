<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_cndata = "localhost";
$database_cndata = "inistitute";
$username_cndata = "root";
$password_cndata = "";
$cndata = mysql_pconnect($hostname_cndata, $username_cndata, $password_cndata) or trigger_error(mysql_error(),E_USER_ERROR); 
?>