<?php require_once('Connections/cndata.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO `admin` (userlogin, password) VALUES (%s, %s)",
                       GetSQLValueString($_POST['userlogin'], "text"),
                       GetSQLValueString($_POST['password'], "text"));

  mysql_select_db($database_cndata, $cndata);
  $Result1 = mysql_query($insertSQL, $cndata) or die(mysql_error());
}

mysql_select_db($database_cndata, $cndata);
$query_Recordset1 = "SELECT * FROM `admin`";
$Recordset1 = mysql_query($query_Recordset1, $cndata) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>إدارة المستخدمين</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--
Template 2042 The Block
http://www.tooplate.com/view/2042-the-block
-->
<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />
  
<!-- Arquivos utilizados pelo jQuery lightBox plugin -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
<!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->

<!-- Ativando o jQuery lightBox plugin -->
<script type="text/javascript">
$(function() {
    $('#map a').lightBox();
});
</script>

</head>
<body>

<div id="tooplate_wrapper">

	<div id="tooplate_header">
	  <div id="tooplate_menu">
          <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li>
                  <div align="right"><a href="adminhome.html" class="current">رجوع</a></div>
              </li>
            </ul>    	
        </div> <!-- end of tooplate_menu -->
    </div> 
	<div align="center"><!-- end of forever header -->
	  
  </div>
	<div align="center"><!-- end of middle -->
	  
  </div>
	<div id="tooplate_content">
	  <div align="center">
	    <table width="494" border="2" cellpadding="2">
	      <tr>
	        <td bgcolor="#999999"><div align="center"><strong>إجراء</strong></div></td>
	        <td bgcolor="#999999"><div align="center"><strong>كلمة المرور</strong></div></td>
	        <td bgcolor="#999999"><div align="center"><strong>اسم الدخول</strong></div></td>
	        <td bgcolor="#999999"><div align="center"><strong>الرقم</strong></div></td>
          </tr>
	      <tr>
	        <?php do { ?>
            <td><div align="center"><a href="updateadmin.php?noo=<?php echo $row_Recordset1['id']; ?>"><strong>تعديل</strong></a></div></td>
            <td><div align="center"><?php echo $row_Recordset1['password']; ?></div></td>
            <td><div align="center"><?php echo $row_Recordset1['userlogin']; ?></div></td>
            <td><div align="center"><?php echo $row_Recordset1['id']; ?></div></td>
	        </tr>
              <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
          
        </table>
      </div>
	  <p>&nbsp;</p>
	  <h3>&nbsp;
	    <p>&nbsp;</p>
        <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
          <table border="0" align="center" dir="rtl">
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">اسم الدخول:</td>
              <td><input type="text" name="userlogin" value="" size="32" /></td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">كلمة المرور:</td>
              <td><input type="text" name="password" value="" size="32" /></td>
            </tr>
            <tr valign="baseline">
              <td nowrap="nowrap" align="right">&nbsp;</td>
              <td><div align="left">
                <input type="submit" value="اضافة" />
              </div></td>
            </tr>
          </table>
          <input type="hidden" name="MM_insert" value="form1" />
        </form>
        <p>&nbsp;</p>
      </h3>
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
	</div> <!-- end of content -->
    
    <div id="tooplate_footer">2018
      <div class="cleaner"></div>
	</div>

</div> <!-- end of wrapper -->

</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
