<?php require_once('Connections/cndata.php'); ?>
 <script>
  function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		<?php 
$PHPtext = "هذا الحقل يقبل أرقام فقط";
?>
var JavaScriptAlert = <?php echo json_encode($PHPtext); ?>;
alert(JavaScriptAlert); 
        return false;
    }
    return true;
}
</script>
        <script>
            function istext(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return true;
    }
			<?php 
$PHPtext = "هذا الحقل يقبل حروف فقط";
?>
var JavaScriptAlert = <?php echo json_encode($PHPtext); ?>;
alert(JavaScriptAlert); 
    return false;
}
</script>

<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO student (name, age, address, Phone, courcename, notes) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['name'], "text"),
                       GetSQLValueString($_POST['age'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['Phone'], "int"),
                       GetSQLValueString($_POST['courcename'], "text"),
                       GetSQLValueString($_POST['notes'], "text"));

  mysql_select_db($database_cndata, $cndata);
  $Result1 = mysql_query($insertSQL, $cndata) or die(mysql_error());

  $insertGoTo = "registerdon.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_cndata, $cndata);
$query_Recordset1 = "SELECT * FROM student";
$Recordset1 = mysql_query($query_Recordset1, $cndata) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_cndata, $cndata);
$query_Recordset2 = "SELECT * FROM cource";
$Recordset2 = mysql_query($query_Recordset2, $cndata) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>تسجيل</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--
Template 2042 The Block
http://www.tooplate.com/view/2042-the-block
-->
<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />
  
<!-- Arquivos utilizados pelo jQuery lightBox plugin -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
<!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->

<!-- Ativando o jQuery lightBox plugin -->
<script type="text/javascript">
$(function() {
    $('#map a').lightBox();
});
</script>

</head>
<body>

<div id="tooplate_wrapper">

	<div id="tooplate_header">
	  <div id="tooplate_menu">
          <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li>
                  <div align="right"><a href="index.html" class="current">الرئيسية</a></div>
              </li>
            </ul>    	
        </div> <!-- end of tooplate_menu -->
    </div> 
	<div align="center"><!-- end of forever header -->
	  
  </div>
	<div align="center"><!-- end of middle -->
	  
  </div>
	<div id="tooplate_content">
	  <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
	    <table align="center" dir="rtl">
		
		
	      <tr valign="baseline">
	        <td nowrap="nowrap" align="right">الاسم رباعي</td>
	        <td><input type="text" name="name" value="" size="32" required onKeyPress="return istext(event)" /></td>
          </tr>
		<!--  
		   <tr valign="baseline">
	        <td nowrap="nowrap" align="right">الرقم الوطني</td>
	        <td><input type="text" name="name" value="" size="32" required onKeyPress="return isNumber(event)" /></td>
          </tr>
		 
		  
		   <tr valign="baseline">
	        <td nowrap="nowrap" align="right">الولاية</td>
	        <td><select name="welaia">
			<option value="الخرطوم"> الخرطوم</option>
			<option value="نهر النيل"> نهر النيل</option>
			<option value="22"> الجزيرة</option>
			<option value=""> البحر الاحمر</option>
			<option value=""> الشمالية</option>
			
			</select>
			</td>
          </tr>
		   -->
		  
	      <tr valign="baseline">
	        <td nowrap="nowrap" align="right">العمر</td>
	        <td><input type="text" name="age" value="" size="15" required onKeyPress="return isNumber(event)" /></td>
          </tr>
		  
		  
	      <tr valign="baseline">
	        <td nowrap="nowrap" align="right" valign="top" >التخصص</td>
	        <td><input type="text" name="address" value="" size="32" required onKeyPress="return istext(event)" /></td>
          </tr>
		  
		  
	      <tr valign="baseline">
	        <td nowrap="nowrap" align="right">الهاتف</td>
	        <td><input type="text" name="Phone" value="" size="32" required onKeyPress="return isNumber(event)" /></td>
          </tr>
		  
		  
	      <tr valign="baseline">
	        <td nowrap="nowrap" align="right">اسم الدورة</td>
	        <td><select name="courcename">
	          <?php 
do {  
?>
	          <option value="<?php echo $row_Recordset2['name']?>" ><?php echo $row_Recordset2['name']?></option>
	          <?php
} while ($row_Recordset2 = mysql_fetch_assoc($Recordset2));
?>
	          </select></td>
          </tr>
	      <tr> </tr>
	      <tr valign="baseline">
	        <td nowrap="nowrap" align="right" valign="top">ملاحظات</td>
	        <td><textarea name="notes" cols="50" rows="5" required></textarea></td>
          </tr>
	      <tr valign="baseline">
	        <td nowrap="nowrap" align="right">&nbsp;</td>
	        <td><div align="left">
	          <input type="submit" value="التسجيل" />
            </div></td>
          </tr>
        </table>
	    <input type="hidden" name="MM_insert" value="form1" />
      </form>
	  <p align="center">&nbsp;</p>
	  <h1>&nbsp;</h1>
	  <p>&nbsp;</p>
	</div> <!-- end of content -->
    
    <div id="tooplate_footer">2018
      <div class="cleaner"></div>
	</div>

</div> <!-- end of wrapper -->
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($Recordset2);
?>
