<?php require_once('Connections/cndata.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_cndata, $cndata);
$query_Recordset1 = "SELECT * FROM cource";
$Recordset1 = mysql_query($query_Recordset1, $cndata) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>الدورات</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--
Template 2042 The Block
http://www.tooplate.com/view/2042-the-block
-->
<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />
  
<!-- Arquivos utilizados pelo jQuery lightBox plugin -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
<!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->

<!-- Ativando o jQuery lightBox plugin -->
<script type="text/javascript">
$(function() {
    $('#map a').lightBox();
});
</script>

</head>
<body>

<div id="tooplate_wrapper">

	<div id="tooplate_header">
	  <div id="tooplate_menu">
          <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li>
                  <div align="right"><a href="index.html" class="current">الرئيسية</a></div>
              </li>
            </ul>    	
        </div> <!-- end of tooplate_menu -->
    </div> 
	<div align="center"><!-- end of forever header -->
	  
  </div>
	<div align="center"><!-- end of middle -->
	  
  </div>
	<div id="tooplate_content">
	  <h3>&nbsp;</h3>
	  <form id="form1" name="form1" method="post" action="">
	    <div align="center"></div>
      </form>
	  <h3 align="center">البيانات التي أدخلتها خاطئة</h3>
	  <p align="center">الرجاء المحاولة مرة أخرى</p>
	  <h3 align="center">
	    <p align="center">&nbsp;</p>
	  </h3>
	  <p>&nbsp;</p>
	</div> <!-- end of content -->
    
    <div id="tooplate_footer">2018
      <div class="cleaner"></div>
	</div>

</div> <!-- end of wrapper -->

</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
