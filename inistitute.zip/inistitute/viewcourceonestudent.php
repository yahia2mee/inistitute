<?php require_once('Connections/cndata.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_Recordset1 = "-1";
if (isset($_GET['nnn'])) {
  $colname_Recordset1 = $_GET['nnn'];
}
mysql_select_db($database_cndata, $cndata);
$query_Recordset1 = sprintf("SELECT * FROM student WHERE courcename = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $cndata) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);$colname_Recordset1 = "-1";
if (isset($_GET['nnn'])) {
  $colname_Recordset1 = $_GET['nnn'];
}
mysql_select_db($database_cndata, $cndata);
$query_Recordset1 = sprintf("SELECT * FROM student WHERE courcename = %s", GetSQLValueString($colname_Recordset1, "text"));
$Recordset1 = mysql_query($query_Recordset1, $cndata) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
  $i=0;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>عرض الدورات</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--
Template 2042 The Block
http://www.tooplate.com/view/2042-the-block
-->
<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />
  
<!-- Arquivos utilizados pelo jQuery lightBox plugin -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
<style type="text/css">
سيب {
	color: #F00;
}
</style>
<!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->

<!-- Ativando o jQuery lightBox plugin -->
<script type="text/javascript">
$(function() {
    $('#map a').lightBox();
});
</script>

</head>
<body>

<div id="tooplate_wrapper">

	<div id="tooplate_header">
	  <div id="tooplate_menu">
          <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li>
                  <div align="right"><a href="index.html" class="current">الرئيسية</a></div>
              </li>
            </ul>    	
        </div> <!-- end of tooplate_menu -->
    </div> 
	<div align="center"><!-- end of forever header -->
	  
  </div>
	<div align="center"><!-- end of middle -->
	  
  </div>
	<div id="tooplate_content">
	  <div align="center">
        <?php if ($totalRows_Recordset1 == 0) { // Show if recordset empty ?>
          <table width="302" border="1">
            <tr>
              <td><div align="center"><strong>عفواً لم يتم تسجيل أي طالب بهذه الدورة</strong></div></td>
            </tr>
          </table>
          <?php } // Show if recordset empty ?>
        <p>&nbsp;</p>
        <?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <p>الطلاب المسجلين في دورة </p>
  <p><strong><?php echo $row_Recordset1['courcename']; ?></strong></p>
  <?php } // Show if recordset not empty ?>
        <?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
        <table width="478" height="88" border="2" cellpadding="2">
          <tr>
            <td height="39" bgcolor="#CCCCCC"><h4 align="center"><strong>الوحدة</strong></h4></td>
            <td bgcolor="#CCCCCC"><h4 align="center"><strong>الاسم</strong></h4></td>
            <td bgcolor="#CCCCCC"><h4 align="center"><strong>الرتبة</strong></h4></td>
            <td bgcolor="#CCCCCC"><h4 align="center"><strong>الرقم</strong></h4></td>
          </tr>
          <tr>
            <?php do { ?>
              <td width="155" height="39"><div align="right"><?php echo $row_Recordset1['address']; ?></div></td>
              <td width="155"><div align="right"><strong><?php echo $row_Recordset1['name']; ?></strong></div></td>
              <td width="88"><div align="right"><?php echo $row_Recordset1['age']; ?></div></td>
              <td width="42"><div align="center"><?php echo ++$i ?></div></td>
</tr>
              <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
                                      

</table>
          <?php } // Show if recordset not empty ?>
<p>&nbsp;</p>
	    <h1 align="left">&nbsp;</h1>
	    <p>&nbsp;</p>
	  </div>
	  <p align="center">&nbsp;</p>
	  <h1>&nbsp;</h1>
	  <p>&nbsp;</p>
	</div> <!-- end of content -->
    
    <div id="tooplate_footer">2016
      <div class="cleaner"></div>
	</div>

</div> <!-- end of wrapper -->

</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($Recordset1);
?>
