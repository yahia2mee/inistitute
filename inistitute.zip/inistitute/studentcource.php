<?php require_once('Connections/cndata.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO corces_student (StudentName, cource) VALUES (%s, %s)",
                       GetSQLValueString($_POST['StudentName'], "text"),
                       GetSQLValueString($_POST['cource'], "text"));

  mysql_select_db($database_cndata, $cndata);
  $Result1 = mysql_query($insertSQL, $cndata) or die(mysql_error());
}

mysql_select_db($database_cndata, $cndata);
$query_Recordset1 = "SELECT * FROM student";
$Recordset1 = mysql_query($query_Recordset1, $cndata) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_cndata, $cndata);
$query_Recordset2 = "SELECT * FROM cource";
$Recordset2 = mysql_query($query_Recordset2, $cndata) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);

mysql_select_db($database_cndata, $cndata);
$query_Recordset3 = "SELECT * FROM corces_student";
$Recordset3 = mysql_query($query_Recordset3, $cndata) or die(mysql_error());
$row_Recordset3 = mysql_fetch_assoc($Recordset3);
$totalRows_Recordset3 = mysql_num_rows($Recordset3);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>الطلاب</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<!--
Template 2042 The Block
http://www.tooplate.com/view/2042-the-block
-->
<link href="css/tooplate_style.css" rel="stylesheet" type="text/css" />
  
<!-- Arquivos utilizados pelo jQuery lightBox plugin -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>
<link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />
<!-- / fim dos arquivos utilizados pelo jQuery lightBox plugin -->

<!-- Ativando o jQuery lightBox plugin -->
<script type="text/javascript">
$(function() {
    $('#map a').lightBox();
});
</script>

</head>
<body>

<div id="tooplate_wrapper">

	<div id="tooplate_header">
	  <div id="tooplate_menu">
          <ul>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
                <li>
                  <div align="right"><a href="adminhome.html" class="current">رجوع</a></div>
              </li>
            </ul>    	
        </div> <!-- end of tooplate_menu -->
    </div> 
	<div align="center"><!-- end of forever header -->
	  
  </div>
	<div align="center"><!-- end of middle -->
	  
  </div>
	<div id="tooplate_content">
	  <div align="center">
	    <table width="497" border="2" cellpadding="2">
	      <tr>
	        <td><div align="center">اجراء</div></td>
	        <td><div align="center">اسم الدورة</div></td>
	        <td><div align="center">اسم الطالب</div></td>
	        <td><div align="center">الرقم</div></td>
          </tr>
	      <tr>
	        <?php do { ?>
            <td><div align="center"><a href="deletestudentcource.php?noo=<?php echo $row_Recordset3['id']; ?>">حذف</a></div></td>
            <td><div align="center"><?php echo $row_Recordset3['cource']; ?></div></td>
            <td><div align="center"><?php echo $row_Recordset3['StudentName']; ?></div></td>
            <td><div align="center"><?php echo $row_Recordset3['id']; ?></div></td>
	       </tr>
              <?php } while ($row_Recordset3 = mysql_fetch_assoc($Recordset3)); ?>
          
        </table>
      </div>
	  <p align="center">&nbsp;</p>
	  <h1>&nbsp;
        <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
          <div align="center">
            <table align="center" dir="rtl">
              <tr valign="baseline">
                <td nowrap="nowrap" align="right"><h4 align="center">اسم الطالب</h4></td>
                <td><select name="StudentName">
                  <?php 
do {  
?>
                  <option value="<?php echo $row_Recordset1['name']?>" ><?php echo $row_Recordset1['name']?></option>
                  <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
?>
                </select></td>
              </tr>
              <tr> </tr>
              <tr valign="baseline">
                <td nowrap="nowrap" align="right"><h4 align="center">رقم الدورة</h4></td>
                <td><select name="cource">
                  <?php
do {  
?>
                  <option value="<?php echo $row_Recordset2['ID']?>"><?php echo $row_Recordset2['ID']?></option>
                  <?php
} while ($row_Recordset2 = mysql_fetch_assoc($Recordset2));
  $rows = mysql_num_rows($Recordset2);
  if($rows > 0) {
      mysql_data_seek($Recordset2, 0);
	  $row_Recordset2 = mysql_fetch_assoc($Recordset2);
  }
?>
                </select></td>
              </tr>
              <tr> </tr>
              <tr valign="baseline">
                <td nowrap="nowrap" align="right">&nbsp;</td>
                <td><div align="justify">
                  <input type="submit" value="اضافة" />
                </div></td>
              </tr>
            </table>
            <input type="hidden" name="MM_insert" value="form1" />
          </div>
        </form>
        <p>&nbsp;</p>
	  </h1>
	  <p>&nbsp;</p>
	</div> <!-- end of content -->
    
    <div id="tooplate_footer">2016
      <div class="cleaner"></div>
	</div>

</div> <!-- end of wrapper -->

</body>
</html>
<?php
mysql_free_result($Recordset1);

mysql_free_result($Recordset2);

mysql_free_result($Recordset3);
?>
